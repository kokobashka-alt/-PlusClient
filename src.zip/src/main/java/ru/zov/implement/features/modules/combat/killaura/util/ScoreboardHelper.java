package ru.zov.implement.features.modules.combat.killaura.util;
import ru.zov.implement.features.modules.combat.killaura.type.Mc;

import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.scoreboard.ScoreAccess;
import net.minecraft.scoreboard.ScoreHolder;
import net.minecraft.scoreboard.ScoreboardDisplaySlot;
import net.minecraft.scoreboard.ScoreboardObjective;
import net.minecraft.text.Text;

public class ScoreboardHelper {
    public static final ScoreboardHelper INSTANCE = new ScoreboardHelper();
    public Text header;

    public String getHeaderAsString() {
        return this.header == null ? "" : this.header.getString();
    }

    public boolean headerContains(String str) {
        return getHeaderAsString().toLowerCase().contains(str);
    }

    public float getHealthBelowName(LivingEntity livingEntity) {
        try {
            PlayerEntity clientPlayerEntity;
            ScoreAccess orCreateScore;
            if ((livingEntity instanceof PlayerEntity) && (clientPlayerEntity = (PlayerEntity) livingEntity) != Mc.INSTANCE.getPlayer()) {
                ClientWorld world = Mc.INSTANCE.getWorld();
                if (world != null && world.getScoreboard() != null) {
                    ScoreboardObjective objectiveForSlot = world.getScoreboard().getObjectiveForSlot(ScoreboardDisplaySlot.BELOW_NAME);
                    if (objectiveForSlot != null && (orCreateScore = world.getScoreboard().getOrCreateScore(ScoreHolder.fromName(livingEntity.getNameForScoreboard()), objectiveForSlot)) != null) {
                        return orCreateScore.getScore() == 0 ? clientPlayerEntity.getHealth() : orCreateScore.getScore();
                    }
                }
            }
            return livingEntity.getHealth();
        } catch (Throwable ignored) {
            return livingEntity != null ? livingEntity.getHealth() : 20.0f;
        }
    }

    public void setHeader(Text text) {
        this.header = text;
    }

    public Text getHeader() {
        return this.header;
    }
}
