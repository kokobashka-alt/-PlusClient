package ru.zov.implement.features.commands.defaults;

import java.util.Arrays;
import java.util.List;
import java.util.Locale;
import java.util.Map.Entry;
import java.util.stream.Stream;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import ru.nexusguard.protection.annotations.Native;
import ru.zov.api.feature.command.Command;
import ru.zov.api.feature.command.IBaritoneChatControl;
import ru.zov.api.feature.command.argument.IArgConsumer;
import ru.zov.api.feature.command.datatypes.KeyDataType;
import ru.zov.api.feature.command.datatypes.ModuleDataType;
import ru.zov.api.feature.command.exception.CommandException;
import ru.zov.api.feature.command.helpers.Paginator;
import ru.zov.api.feature.command.helpers.TabCompleteHelper;
import ru.zov.api.feature.module.Module;
import ru.zov.api.feature.module.ModuleProvider;
import ru.zov.api.feature.module.ModuleRepository;
import ru.zov.common.util.other.StringUtil;
import ru.zov.core.Main;

public class BindCommand extends Command {
   private final ModuleProvider moduleProvider;
   private final ModuleRepository moduleRepository;

   public BindCommand(Main main) {
      super("bind");
      this.moduleRepository = main.getModuleRepository();
      this.moduleProvider = main.getModuleProvider();
   }

   @Native
   @Override
   public void execute(String label, IArgConsumer args) throws CommandException {
      String action = args.hasAny() ? args.getString().toLowerCase(Locale.US) : "list";
      switch (action) {
         case "add":
            this.handleAddBind(args);
            break;
         case "remove":
            this.handleRemoveBind(args);
            break;
         case "list":
            this.handleListBinds(args, label);
            break;
         case "clear":
            this.handleClearBinds(args);
      }
   }

   @Native
   private void handleAddBind(IArgConsumer args) throws CommandException {
      args.requireMin(2);
      String moduleName = args.getString();
      int key = args.<Entry<String, Integer>, KeyDataType>getDatatypeFor(KeyDataType.INSTANCE).getValue();
      Module module = this.moduleProvider.get(moduleName);
      module.setKey(key);
      this.logDirect(
         Formatting.GREEN
            + "Модуль "
            + Formatting.RED
            + moduleName
            + Formatting.GREEN
            + " привязан к кнопке "
            + Formatting.RED
            + StringUtil.getBindName(key).toLowerCase()
      );
   }

   @Native
   private void handleRemoveBind(IArgConsumer args) throws CommandException {
      args.requireMax(1);
      String moduleName = args.getString();
      Module module = this.moduleProvider.get(moduleName);
      module.setKey(-1);
      this.logDirect(Formatting.GREEN + "Бинд для модуля " + Formatting.RED + moduleName + Formatting.GREEN + " был успешно удален!");
   }

   @Native
   private void handleListBinds(IArgConsumer args, String label) throws CommandException {
      args.requireMax(1);
      Paginator.paginate(
         args,
         new Paginator<>(this.moduleRepository.modules().stream().filter(module -> module.getKey() != -1).toList()),
         () -> this.logDirect("Список модулей:"),
         module -> {
            String names = module.getName();
            String keys = StringUtil.getBindName(module.getKey()).toLowerCase();
            return Text.literal(Formatting.GRAY + "Название: " + Formatting.WHITE + names)
               .append(Text.literal(Formatting.GRAY + " Клавиша: " + Formatting.WHITE + keys));
         },
         IBaritoneChatControl.FORCE_COMMAND_PREFIX + label
      );
   }

   @Native
   private void handleClearBinds(IArgConsumer args) throws CommandException {
      args.requireMax(1);
      this.moduleRepository.modules().forEach(function -> function.setKey(-1));
      this.logDirect("Все бинды модулей были удалены.", Formatting.GREEN);
   }

   @Native
   @Override
   public Stream<String> tabComplete(String label, IArgConsumer args) throws CommandException {
      if (args.hasExactlyOne()) {
         return new TabCompleteHelper().sortAlphabetically().prepend("add", "remove", "list", "clear").filterPrefix(args.getString()).stream();
      }

      String arg = args.getString();
      if (arg.equalsIgnoreCase("add")) {
         if (args.hasExactly(1)) {
            return args.tabCompleteDatatype(ModuleDataType.INSTANCE);
         }

         if (args.hasExactly(2)) {
            return args.tabCompleteDatatype(KeyDataType.INSTANCE);
         }
      }

      return Stream.empty();
   }

   @Override
   public String getShortDesc() {
      return "Управление биндами для модулей.";
   }

   @Native
   @Override
   public List<String> getLongDesc() {
      return Arrays.asList(
         "Эта команда позволяет управлять биндами для модулей, которые будут активироваться при нажатии определённых клавиш.",
         "",
         "Использование:",
         "> bind add <module> <key> - Привязывает модуль к указанной клавише.",
         "> bind remove <module> - Удаляет привязку модуля.",
         "> bind list - Показывает список всех текущих биндов модулей.",
         "> bind clear - Удаляет все бинды модулей."
      );
   }
}
